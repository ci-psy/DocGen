"""py-code-docgen - A powerful documentation generator."""

__version__ = "0.1.6" 